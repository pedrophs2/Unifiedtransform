<div class="loader">
    <img src="{{asset('01-progress.gif')}}" class="loader-gif" />
</div>