<?php

namespace App;

use App\Model;

class Payment extends Model
{
    //
}
